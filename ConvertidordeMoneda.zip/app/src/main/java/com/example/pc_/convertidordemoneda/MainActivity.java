package com.example.pc_.convertidordemoneda;

import android.app.Dialog;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.media.SoundPool;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button convertirBoton1;
    private Button elegirMoneda;
    private TextView elegirMonedas;
    private EditText moneda;
    double dolarMoneda = 0;
    private String[] monedas;
    public SoundPool sp;
    public int flujodemusica=0;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        monedas = getResources().getStringArray(R.array.monedas);
        elegirMonedas = (TextView)findViewById(R.id.dolar);
        Button boton1 = (Button)findViewById(R.id.convertirBoton1);
        moneda = (EditText)findViewById(R.id.moneda);

        monedas = getResources().getStringArray(R.array.monedas);
        sp = new SoundPool(8, AudioManager.STREAM_MUSIC, 0);
        this.setVolumeControlStream(AudioManager.STREAM_MUSIC);
        flujodemusica = sp.load(this,R.raw.sonido,1);

        final TextView res =(TextView)findViewById(R.id.resultado);

        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(dolarMoneda==0) {
                        Toast.makeText(getApplicationContext(),
                                "¡ERROR! ¡Primero selecciona un tipo de moneda!",
                                Toast.LENGTH_LONG).show();
                    }else {
                        double peso = new Double(moneda.getText().toString());
                        play_sp();
                        res.setText("$" + (peso * dolarMoneda));
                    }
                }catch(NumberFormatException ex){
                    Toast.makeText(getApplicationContext(),
                            "¡ERROR! ¡Solo se deben insertar valores numericos!",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void play_sp(){
        sp.play(flujodemusica, 1, 1, 0, 0, 1);
    }

    public void abre_dialogo(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.escoge_moneda);
        builder.setItems(R.array.monedas, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                if(which==0) {
                    elegirMonedas.setText("Dolares ($)");
                    dolarMoneda = 19.94;
                }else if(which==1){
                    elegirMonedas.setText("Euros (€)");
                    dolarMoneda = 23.38;
                }else if(which==2){
                    elegirMonedas.setText("Libras (£)");
                    dolarMoneda = 26.61;
                }else if(which==3){
                    elegirMonedas.setText("Yenes (¥)");
                    dolarMoneda = 0.18;
                }
            }
        });
        Dialog dialog = builder.create();
        dialog.show();
    }
}